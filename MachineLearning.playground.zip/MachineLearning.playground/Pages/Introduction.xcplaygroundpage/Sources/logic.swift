import UIKit

public class SimulationScene : UIView {
    
    public init() {
        super.init(frame: CGRect(x: 0, y: 0, width: 500, height: 300))
        self.backgroundColor = #colorLiteral(red: 0.9428111294, green: 0.9428111294, blue: 0.9428111294, alpha: 1)
        
        //Create the circle
        let circle = UIView(frame: CGRect(x: 100, y: 135, width: 30, height: 30))
        circle.backgroundColor = #colorLiteral(red: 0.4633018092, green: 0.4633018092, blue: 0.4633018092, alpha: 1)
        circle.layer.cornerRadius = 15
        circle.layer.borderWidth = 3.0
        circle.layer.borderColor = #colorLiteral(red: 0.2512571216, green: 0.2528424561, blue: 0.2970899045, alpha: 1)
        
        self.addSubview(circle)
        
        //Create the obstacle
        let obstacle = UIView(frame: CGRect(x: 220, y: 110, width: 30, height: 80))
        obstacle.backgroundColor = #colorLiteral(red: 1, green: 0.3803062466, blue: 0.322109748, alpha: 1)
        obstacle.layer.cornerRadius = 5
        obstacle.layer.cornerRadius = 10
        obstacle.layer.borderWidth = 3.0
        obstacle.layer.borderColor = #colorLiteral(red: 0.7671440972, green: 0.2910199262, blue: 0.2446413585, alpha: 1)
        self.addSubview(obstacle)
        
        //Create the goal
        let goal = UIView(frame: CGRect(x: 400, y: 135, width: 30, height: 30))
        goal.backgroundColor = #colorLiteral(red: 0.5084224626, green: 1, blue: 0.4952215415, alpha: 1)
        goal.layer.cornerRadius = 5
        goal.layer.cornerRadius = 10
        goal.layer.borderWidth = 3.0
        goal.layer.borderColor = #colorLiteral(red: 0.361868898, green: 0.7117484466, blue: 0.3524731629, alpha: 1)
        self.addSubview(goal)
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
