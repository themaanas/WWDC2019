import PlaygroundSupport
//: [**Previous**](@previous)
/*:
 # Simulation
 
Here's the simulation in action. Let me walk you through it, because it might be a little confusing at first.
 - Important:
 When I say "organism," I'm referring to each circle. Even though it might sound weird, using biological terms is fitting because this is basically a simulation of evolution in nature. Just like how some species' goals are to hunt more effectively or camouflage into their surroundings, our organism's goal is to get to the green square.
 
 1. Each organism has 30 available movements in order to get to the green square. During the first generation of organisms, each movement is completely random. It may look as though the circles are multiplying, but this isn't the case. Each of the 300 circles starts out at the same spot so when they move randomly, they come out from under each other.
 2. If the circle touches the obstacle, it immediately dies. This represents the death of an organism with a bad trait in a species.
 3. After each organism has moved 30 times, we check each one to see which is closest to the green square. (It'll show up as green) The closest organism will be the "parent" for the next generation. In most genetic algorithms, breeding occurs between two parents but in our case it's much easier to just use one.
 4. Once we find the closest organism, we save the path that it took to a variable. Then, we reset all of the circles back to their original position so that generation 2 can do its thing.
 5. During generation 2 and every generation after, the organisms don't always move randomly. Most of the time, they follow the movements of the parent of the previous generation. However, there is a 5% chance that it will "mutate" and move randomly. This is how the species will progress toward their end goal: getting to the green square.
 5. This keeps repeating until eventually, one circle finally gets to the green square.
 */
let Simulation = SimulationsScene()
/*:
 ### Experiment with values
 Here's a bunch of values you can play around with.
 
 ***populationSize*** changes the amount of circles that appear.
 */
Simulation.populationSize = 400
/*:
 ***useAnimations*** is useful if you are running this playground on an older Mac, or if the population size is really high. (Set it to false under these circumstances)
 */
Simulation.useAnimations = true
/*:
 ***obstacleX***, ***obstacleY***, ***obstacleWidth***, and ***obstacleHeight*** changes the coordinates and dimensions of the obstacle.
 */
Simulation.obstacleX = 220
Simulation.obstacleY = 110
Simulation.obstacleWidth = 30
Simulation.obstacleHeight = 80
/*:
 ***movesPerGeneration*** changes the amount of steps an organism can move in a single generation.
 */
Simulation.movesPerGeneration = 30
Simulation.start()
PlaygroundPage.current.liveView = Simulation
/*:
 ### Recap of what we learned:
 - We learned how to set fields of classes in order to change the outcome of a program
 - We took a quick crash course in biology and learned how natural selection works
 - We learned how to apply the concept of natural selection to software
 - (Hopefully 😄) We had fun learning about an important part of the tech world
 
 Artificial intelligence is something that I've been really interested in for quite a while. I had fun making this and I hope you enjoyed learning about it as well. I look forward to meeting everyone at WWDC 2019!
*/
