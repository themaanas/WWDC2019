import UIKit

public class SimulationsScene : UIView {
    
    //Fields
    public var populationSize = 100
    public var useAnimations = true
    public var obstacleX = 0
    public var obstacleY = 0
    public var obstacleWidth = 0
    public var obstacleHeight = 0
    public var movesPerGeneration = 30
    
    //Global variables
    let timeBetweenMoves = 0.3
    var paths = [[[Int]]]()
    var bestPath = [[Int]]()
    var circles = [UIView()]
    var indexesToBlock = [Int]()
    var generationCounter = 1
    var moveCounter = 0
    var simulationTimer = Timer()
    var goal : UIView
    var obstacle : UIView
    var genLabel : UILabel
    var genBackground : UIView
    var bestIndex = 0
    
    
    public init() {
        //Create the rectangle obstacle
        obstacle = UIView()
        obstacle.backgroundColor = #colorLiteral(red: 1, green: 0.3803062466, blue: 0.322109748, alpha: 1)
        obstacle.layer.cornerRadius = 5
        obstacle.layer.cornerRadius = 10
        obstacle.layer.borderWidth = 3.0
        obstacle.layer.borderColor = #colorLiteral(red: 0.7671440972, green: 0.2910199262, blue: 0.2446413585, alpha: 1)
        
        
        //Create the goal
        goal = UIView(frame: CGRect(x: 400, y: 135, width: 30, height: 30))
        goal.backgroundColor = #colorLiteral(red: 0.5084224626, green: 1, blue: 0.4952215415, alpha: 1)
        goal.layer.cornerRadius = 5
        goal.layer.cornerRadius = 10
        goal.layer.borderWidth = 3.0
        goal.layer.borderColor = #colorLiteral(red: 0.361868898, green: 0.7117484466, blue: 0.3524731629, alpha: 1)
        
        //Create the generation counter label and background
        genLabel = UILabel(frame: CGRect(x: 175, y: 10, width: 150, height: 30))
        genLabel.text = "GENERATION: \(generationCounter)"
        let cfURL = Bundle.main.url(forResource: "ubuntu", withExtension: "ttf") as! CFURL
        CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil)
        genLabel.font = UIFont(name: "UbuntuMono-Bold", size: 20.0)
        genLabel.textAlignment = .center
        genBackground = UIView(frame: CGRect(x: 170, y: 10, width: 160, height: 30))
        genBackground.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        genBackground.layer.cornerRadius = 15
        genBackground.layer.borderColor = #colorLiteral(red: 0.7992278874, green: 0.7992278874, blue: 0.7992278874, alpha: 1)
        genBackground.layer.borderWidth = 3.0
        
        
        super.init(frame: CGRect(x: 0, y: 0, width: 500, height: 300))
        self.backgroundColor = #colorLiteral(red: 0.9428111294, green: 0.9428111294, blue: 0.9428111294, alpha: 1)
        
        circles.removeAll()
        paths.removeAll()
        indexesToBlock.removeAll()
    }
    
    public func start() {
        
        obstacle.frame = CGRect(x: obstacleX, y: obstacleY, width: obstacleWidth, height: obstacleHeight)
        
        //Add all the elements to the view
        self.addSubview(goal)
        self.addSubview(obstacle)
        
        
        for _ in 0..<populationSize {
            let circle = UIView(frame: CGRect(x: 100, y: 135, width: 30, height: 30))
            circle.backgroundColor = #colorLiteral(red: 0.4633018092, green: 0.4633018092, blue: 0.4633018092, alpha: 1)
            circle.layer.cornerRadius = 15
            circle.layer.borderWidth = 3.0
            circle.layer.borderColor = #colorLiteral(red: 0.2512571216, green: 0.2528424561, blue: 0.2970899045, alpha: 1)
            
            self.addSubview(circle)
            circles.append(circle)
            paths.append([[Int]]())
        }
        
        self.addSubview(genBackground)
        self.addSubview(genLabel)
        
        //Start the timer for the first generation
        simulationTimer = Timer.scheduledTimer(timeInterval: timeBetweenMoves, target: self, selector: #selector(firstGenerationMovement), userInfo: nil, repeats: true)
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //This only executes for the first generation
    @objc func firstGenerationMovement() {
        //Checks if all the moves have been used up for the current generation
        if moveCounter == movesPerGeneration {
            generationCounter += 1
            simulationTimer.invalidate()
            var lowestDistance = 100000000000;
            
            //Finds the circle with the shortest distance to the goal
            for index in 0 ..< populationSize {
                if Int(distance(circles[index].center, goal.center)) < lowestDistance && !indexesToBlock.contains(index) {
                    lowestDistance = Int(distance(circles[index].center, goal.center))
                    bestIndex = index
                }
            }
            circles[bestIndex].backgroundColor = #colorLiteral(red: 0.6947573101, green: 1, blue: 0.7190243261, alpha: 1)
            circles[bestIndex].layer.borderColor = #colorLiteral(red: 0.5899549093, green: 0.8491525037, blue: 0.6105613067, alpha: 1)
            self.bringSubviewToFront(circles[bestIndex])
            bestPath = paths[bestIndex]
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                // Resets the view and starts the next generation timer
                self.reset()
                self.simulationTimer = Timer.scheduledTimer(timeInterval: self.timeBetweenMoves, target: self, selector: #selector(self.everyOtherGenerationMovement), userInfo: nil, repeats: true)
                
            }
            
            return
        }
        
        //Decides how to move each organism
        for index in 0..<populationSize {
            var direction = Int.random(in: 0...3)
            
            if !indexesToBlock.contains(index) {
                paths[index].append([index,direction])
                move(index: index, direction: direction)
            }
            
            //Checks if the organism is touching the obstacle
            if obstacle.frame.intersects(circles[index].frame) {
                indexesToBlock.append(index)
                circles[index].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0)
                circles[index].layer.borderWidth = 0
            }
        }
        moveCounter += 1
        
        //Checks if the organism has reached the goal and presents view
        for circle in circles {
            if CGRect(x: 405, y: 140, width: 20, height: 20).intersects(circle.frame) {
                self.bringSubviewToFront(circle)
                simulationTimer.invalidate()
                let finishedModal = UIView(frame: CGRect(x: 100, y: 300, width: 300, height: 200))
                finishedModal.backgroundColor = .white
                finishedModal.layer.cornerRadius = 30
                
                let finishedLabel = UILabel(frame: CGRect(x: 125, y: 300, width: 250, height: 200))
                finishedLabel.text = "Congrats! The circle made it to the goal!"
                finishedLabel.numberOfLines = 3
                finishedLabel.lineBreakMode = .byWordWrapping
                let cfURL = Bundle.main.url(forResource: "ubuntu", withExtension: "ttf") as! CFURL
                CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil)
                finishedLabel.font = UIFont(name: "UbuntuMono-Bold", size: 30)
                finishedLabel.textAlignment = .center
                
                let darkBackground = UIView(frame: CGRect(x: 0, y: 0, width: 500, height: 300))
                darkBackground.layer.opacity = 0
                darkBackground.backgroundColor = .black
                
                self.addSubview(darkBackground)
                self.addSubview(finishedModal)
                self.addSubview(finishedLabel)
                
                UIView.animate(withDuration: 0.7) {
                    finishedModal.frame = CGRect(x: 100, y: 50, width: 300, height: 200)
                    finishedLabel.frame = CGRect(x: 125, y: 50, width: 250, height: 200)
                    darkBackground.layer.opacity = 0.6
                }
                return
            }
        }
    }
    
    //This executes for every generation after the first
    @objc func everyOtherGenerationMovement() {
        //Checks if all the moves have been used up for the current generation
        if moveCounter == movesPerGeneration {
            generationCounter += 1
            simulationTimer.invalidate()
            var lowestDistance = 100000000000;
            
            //Finds the circle with the shortest distance to the goal
            for index in 0 ..< populationSize {
                if Int(distance(circles[index].center, goal.center)) < lowestDistance && !indexesToBlock.contains(index){
                    lowestDistance = Int(distance(circles[index].center, goal.center))
                    bestIndex = index
                }
            }
            bestPath = paths[bestIndex]
            circles[bestIndex].backgroundColor = #colorLiteral(red: 0.6947573101, green: 1, blue: 0.7190243261, alpha: 1)
            circles[bestIndex].layer.borderColor = #colorLiteral(red: 0.5899549093, green: 0.8491525037, blue: 0.6105613067, alpha: 1)
            self.bringSubviewToFront(circles[bestIndex])
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                // Resets the view and starts the next generation timer
                self.reset()
                self.simulationTimer = Timer.scheduledTimer(timeInterval: self.timeBetweenMoves, target: self, selector: #selector(self.everyOtherGenerationMovement), userInfo: nil, repeats: true)
                
            }
            
            
            return
        }
        
        //Decides how to move each organism
        for index in 0..<populationSize {
            let direction = Int.random(in: 0...3)
            let chance = Int.random(in: 0..<20)
        
            if !obstacle.frame.intersects(circles[index].frame) {
                //1 in 20 chance of mutation
                if chance == 0 {
                    paths[index].append([index, direction])
                    move(index: index, direction: direction)
                } else {
                    move(index: index, direction: bestPath[moveCounter][1])
                    paths[index].append(bestPath[moveCounter])
                
                }
            } else {
                indexesToBlock.append(index)
                circles[index].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0)
                circles[index].layer.borderWidth = 0
            }
        }
        
        moveCounter += 1
        
        //Checks if the organism has reached the goal and presents view
        for circle in circles {
            if CGRect(x: 405, y: 140, width: 20, height: 20).intersects(circle.frame) {
                self.bringSubviewToFront(circle)
                simulationTimer.invalidate()
                let finishedModal = UIView(frame: CGRect(x: 100, y: 300, width: 300, height: 200))
                finishedModal.backgroundColor = .white
                finishedModal.layer.cornerRadius = 30
                
                let finishedLabel = UILabel(frame: CGRect(x: 125, y: 300, width: 250, height: 200))
                finishedLabel.text = "Congrats! The circle made it to the goal!"
                finishedLabel.numberOfLines = 3
                finishedLabel.lineBreakMode = .byWordWrapping
                let cfURL = Bundle.main.url(forResource: "ubuntu", withExtension: "ttf") as! CFURL
                CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil)
                finishedLabel.font = UIFont(name: "UbuntuMono-Bold", size: 30)
                finishedLabel.textAlignment = .center
                
                let darkBackground = UIView(frame: CGRect(x: 0, y: 0, width: 500, height: 300))
                darkBackground.layer.opacity = 0
                darkBackground.backgroundColor = .black
                
                self.addSubview(darkBackground)
                self.addSubview(finishedModal)
                self.addSubview(finishedLabel)
                
                UIView.animate(withDuration: 0.7) {
                    finishedModal.frame = CGRect(x: 100, y: 50, width: 300, height: 200)
                    finishedLabel.frame = CGRect(x: 125, y: 50, width: 250, height: 200)
                    darkBackground.layer.opacity = 0.6
                }
                
                return
            }
        }
        
    }
    
    
    //Left is 0
    //Up is 1
    //Right is 2
    //Down is 3
    func move(index: Int, direction: Int) {
        var xChange = 0
        var yChange = 0
        
        switch direction {
        case 0:
            xChange = -25
        case 1:
            yChange = -25
        case 2:
            xChange = 25
        case 3:
            yChange = 25
        default:
            //This will never execute.
            print("Something went wrong. Check all of the calls to the move function to make sure the parameters are valid.")
        }
        
        let circle = self.circles[index].frame
        if useAnimations {
            UIView.animate(withDuration: 0.2, animations: {
                self.circles[index].frame = CGRect(x: circle.origin.x + CGFloat(xChange), y: circle.origin.y + CGFloat(yChange), width: circle.width, height: circle.height)
            })
        } else {
            self.circles[index].frame = CGRect(x: circle.origin.x + CGFloat(xChange), y: circle.origin.y + CGFloat(yChange), width: circle.width, height: circle.height)
        }
        
    }
    
    //Finds the distance between two CGPoints
    func distance(_ a: CGPoint, _ b: CGPoint) -> CGFloat {
        let xDist = a.x - b.x
        let yDist = a.y - b.y
        return CGFloat(sqrt(xDist * xDist + yDist * yDist))
    }
    
    //Resets all temp variables and moves all the circles back to their original spot
    func reset() {
        moveCounter = 0
        indexesToBlock.removeAll()
        genLabel.text = "GENERATION: \(generationCounter)"
        self.bringSubviewToFront(genBackground)
        self.bringSubviewToFront(genLabel)
        for index in 0..<paths.count {
            paths[index].removeAll()
        }
        for circle in circles {
            UIView.animate(withDuration: 0.5, animations: {
                circle.frame = CGRect(x: 100, y: 135, width: 30, height: 30)
            })
            
            circle.backgroundColor = #colorLiteral(red: 0.4633018092, green: 0.4633018092, blue: 0.4633018092, alpha: 1)
            circle.layer.borderColor = #colorLiteral(red: 0.2512571216, green: 0.2528424561, blue: 0.2970899045, alpha: 1)
            circle.layer.borderWidth = 3.0
        }
    }
}
